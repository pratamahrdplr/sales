<?php include('dbcon.php');
dbcon();
?>

<!DOCTYPE html>
<html class="no-js">

<head>
	<title>SISTEM MARKETING PT. PLR</title>
	<meta name="description" content="PT SBK">
	<meta name="author" content="Nizar">
	<meta charset="UTF-8">

	<!-- Bootstrap -->
	<link href="images/logo.png" rel="icon" type="image">
	<link href="bootstrap/css/index_background.css" rel="stylesheet" media="screen" />
	<link href="bootstrap/css/bootstrap.min.css" rel="stylesheet" media="screen" />
	<link href="bootstrap/css/bootstrap-responsive.min.css" rel="stylesheet" media="screen" />
	<link href="bootstrap/css/font-awesome.css" rel="stylesheet" media="screen" />
	<link href="bootstrap/css/my_style.css" rel="stylesheet" media="screen" />
	<link href="assets/styles.css" rel="stylesheet" media="screen" />

	<!-- index css -->
	<link href="bootstrap/css/index.css" rel="stylesheet" media="screen" />
	<!-- data table css -->
	<link href="assets/DT_bootstrap.css" rel="stylesheet" media="screen" />
	<!-- notification  -->
	<link href="vendors/jGrowl/jquery.jgrowl.css" rel="stylesheet" media="screen" />

	<script src="vendors/jquery-1.9.1.min.js"></script>
	<script src="vendors/modernizr-2.6.2-respond-1.1.0.min.js"></script>
</head>