<center>
	<footer>
		<p>PT. Pratama Langgeng Raya @2020</p>
	</footer>
</center>