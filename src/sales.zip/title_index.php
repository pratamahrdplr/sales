				
	<div class="row-fluid">
			<div class="span12"></div>
				  <div class="row-fluid">
						<div class="span10">
						<img class="index_logo" src="images/sclogo.png">
						</div>	
						<div class="span12">
							<div class="motto">
							<p>SELAMAT&nbsp;DATANG &nbsp;DI:</p>
							<p>Sistem Marketing PT Sinar Bacan Khatulistiwa</p>												
							</div>											
						</div>							
				  </div>		   							
    </div>	
				