<center>
		<footer>
		<p>PT. Sinar Bacan Khatulistiwa @2016</p>	
		</footer>
</center>

